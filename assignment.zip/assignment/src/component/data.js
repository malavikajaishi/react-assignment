var initialState ={datalist : []}

var data = (state=initialState,action) => {

    switch(action.type){
        case 'FORM_DATA':
            var updateState= Object.assign({},state,{
                datalist:[
                    ...state.datalist,
                    action.data.formdata
                ]

            })

            return updateState;
            default:
                return state

    }
}

export default data;