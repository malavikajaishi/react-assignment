
import React from 'react';
// import ReactDOM from 'react-dom';
import { createStore } from 'redux';
import data from './data'

const store = createStore(data)


class Book extends React.Component {
    constructor() {
        super()
        this.state = {
            fetchedData: [],
            picKey: '',
            formValues: {
                
                firstname: '',
                picture: null,
                lastname: '',
                number: '',
                email: '',
                address: ''
            },
            formErrors: {
                firstname: '',
                lastname: '',
                number: '',
                picture: '',
                email: '',
                address: ''
            },
            formValid: {
                firstname: false,
                lastname: false,
                number: false,
                email: false,
                picture: false,
                address: false
            },
            buttonActive: false,
            buttonClicked: '',
        }
        // this.baseState = this.state.formValues;
    }

    onSubmit = (event) => {
        event.preventDefault()
        var action = {
            type: 'FORM_DATA',
            data: {
                formdata: this.state.formValues,
            }
        }
        store.dispatch(action)
        let randomString = Math.random().toString(36);
        console.log(randomString)


        this.setState({
            buttonActive: false,
            // formValues: this.baseState,
            picKey: randomString,
            formValues: {
                firstname: '',
                picture: null,
                lastname: '',
                number: '',
                email: '',
                address: ''
            }
        });
    }


    validator = (event) => {
        // console.log(this.state)
        var formError = this.state.formErrors;
        var formValid = this.state.formValid;
        var formValues = this.state.formValues;
        if (event.target.name === "firstname") {
            // console.log(this.state)
            let regEx = /([^a-zA-z])/
            if (event.target.value.length === 0) {
                formError.firstname = 'Field required';
                formValid.firstname = false;
                formValues.firstname = '';
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else if (event.target.value.match(regEx) || event.target.value.length > 15) {
                // console.log(event.target.value)
                // console.log("correfct")
                formError.firstname = 'First name should be alphabetical string with 1-15 characters';
                formValid.firstname = false;
                formValues.firstname = '';
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else {
                formError.firstname = '';
                formValid.firstname = true;
                formValues.firstname = event.target.value;
                this.setState({ formErrors: formError, formValid: formValid, formValues: formValues })
            }
        }
        else if (event.target.name === "lastname") {
            // console.log(this.state)
            let regEx = /([^a-zA-z])/
            if (event.target.value.length === 0) {
                formError.lastname = 'Field required';
                formValid.lastname = false;
                formValues.lastname = '';
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else if (event.target.value.match(regEx) || event.target.value.length > 15) {
                // console.log(event.target.value)
                // console.log("correfct")
                formError.lastname = 'Last name should be alphabetical string with 1-15 characters';
                formValid.lastname = false;
                formValues.lastname = '';
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else {
                formError.lastname = '';
                formValid.lastname = true;
                formValues.lastname = event.target.value;
                this.setState({ formErrors: formError, formValid: formValid, formValues: formValues })
            }
        }
        else if (event.target.name === "number") {
            // console.log(this.state)
            let regEx = /^[1-9]([0-9]){9}$/
            if (event.target.value.length === 0) {
                formError.number = 'Field required';
                formValid.number = false;
                formValues.number = event.target.value;
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else if (!event.target.value.match(regEx)) {
                // console.log(event.target.value)
                // console.log("correfct")
                formError.number = 'Contact Number should be a 10 digit number';
                formValid.number = false;
                formValues.number = event.target.value;
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else {
                formError.number = '';
                formValid.number = true;
                formValues.number = event.target.value;
                this.setState({ formErrors: formError, formValid: formValid, formValues: formValues })
            }
        }
        else if (event.target.name === "email") {
            // console.log(this.state)
            let regEx = /\S+@\S+\.\S+/
            if (event.target.value.length === 0) {
                formError.email = 'Field required';
                formValid.email = false;
                formValues.email = event.target.value;
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else if (!event.target.value.match(regEx)) {
                // console.log(event.target.value)
                // console.log("correfct")
                formError.email = 'Enter a Valid email id';
                formValid.email = false;
                formValues.email = event.target.value;
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else {
                formError.email = '';
                formValid.email = true;
                formValues.email = event.target.value;
                this.setState({ formErrors: formError, formValid: formValid, formValues: formValues })
            }
        }
        else if (event.target.name === "address") {
            if (event.target.value.length === 0) {
                formError.address = 'Field required';
                formValid.address = false;
                formValues.address = '';
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else if (event.target.value.length > 200) {
                // console.log(event.target.value)
                // console.log("correfct")
                formError.address = 'Enter a valid Address';
                formValid.address = false;
                formValues.address = '';
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else {
                formError.address = '';
                formValid.address = true;
                formValues.address = event.target.value;
                this.setState({ formErrors: formError, formValid: formValid, formValues: formValues })
            }
        }
        else if (event.target.name === "picture") {
            const regEx = /jpg|png|jpeg/;
            // var keyid
            console.log(event.target.files[0])
            if (event.target.files.length === 0) {
                formError.picture = 'Image Required';
                formValid.picture = false;
                formValues.picture = '';
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else if (!event.target.files[0].type.match(regEx)) {

                formError.picture = 'Invalid file';
                formValid.picture = false;
                formValues.picture = '';
                this.setState({
                    formErrors: formError,
                    formValid: formValid,
                    formValues: formValues
                })
            }
            else {
                formError.picture = '';
                formValid.picture = true;
                formValues.picture = URL.createObjectURL(event.target.files[0]);
                this.setState({ formErrors: formError, formValid: formValid, formValues: formValues })
            }
        }
        let randomString = Math.random().toString(36);
        // console.log(randomString)
        formValues.key = randomString

        let button = formValid.firstname && formValid.lastname && formValid.number && formValid.picture
            && formValid.email && formValid.address

        this.setState({ buttonActive: button, formValues: formValues })
    }
    getRows = () => {
        var rowArr = this.state.fetchedData.map((per) => {
            return (
                <tr key={per.number}>
                    <td>{per.firstName}</td>
                    <td>{per.lastName}</td>
                    <td><img height="100px" width="100px" src={per.picture} alt="ProfilePic" /></td>
                    <td>{per.number}</td>
                    <td>{per.email}</td>
                    <td>{per.address}</td>
                </tr>
            )
        })
        return rowArr;
    }


    render() {
        console.log(this.state.fetchedData)
        store.subscribe(() => {
            // console.log(store.getState().persons)
            this.setState({ fetchedData: store.getState().datalist, key: store.getState().key })
        })
        var rowArr = this.state.fetchedData.map((per) => {
            return (
                <tr key={per.key}>
                    <td style={{wordWrap:"break-word"}}>{per.firstname}</td>
                    <td style={{wordWrap:"break-word"}}>{per.lastname}</td>
                    <td style={{wordWrap:"break-word"}}><img height="100px" width="100px" src={per.picture} alt="ProfilePic" /></td>
                    <td style={{wordWrap:"break-word"}}>{per.number}</td>
                    <td style={{wordWrap:"break-word"}}>{per.email}</td>
                    <td style={{wordWrap:"break-word"}}>{per.address}</td>
                </tr>
            )
        })
        return (
            <div class="container-fluid" >
                <div className="row" style={{paddingTop:"50px", backgroundColor:"#80ffaa"}}>
                    <div className="col-md-3"></div>
                    <br /> 
                    <div className="col-md-6" >
                        <div className="card" style={{border:"5px solid  #008000",backgroundColor:"#ccffee"}}>
                        <form className='form' style={{margin:"20px"}} >
                            <h5 className="text-danger">*All fields are mandatory</h5>
                            <div className="form-group" >
                                <label htmlFor="firstname" className="text-success font-weight-bold">Firstname<sup className="text-danger">*</sup>:</label>
                                <input type="text" value={this.state.formValues.firstname} className="form-control" id="firstname" placeholder="First Name" name="firstname" onChange={this.validator} />
                                <div className="text text-danger">{this.state.formErrors.firstname}</div>
                            </div>
                            <div className="form-group">
                                <label htmlFor="lastname" className="text-success font-weight-bold">Lastname<sup className="text-danger">*</sup>:</label>
                                <input type="text" value={this.state.formValues.lastname} className="form-control" id="lastname" placeholder="Last Name" name="lastname" onChange={this.validator} />
                                <div className="text text-danger">{this.state.formErrors.lastname}</div>
                            </div>
                            <div className="form-group">
                                <label htmlFor="picture" className="text-success font-weight-bold">Picture<sup className="text-danger">*</sup>:</label>
                                <input type="file" accept=".jpeg, .jpg, .png" key={this.state.picKey || ''} className="form-control-file" id="picture" name="picture" onChange={this.validator} />
                                <div className="text text-danger">{this.state.formErrors.picture}</div>
                            </div>
                            <div className="form-group">
                                <label htmlFor="number" className="text-success font-weight-bold">Number<sup className="text-danger">*</sup>:</label>
                                <input type="text" value={this.state.formValues.number} className="form-control" id="cid" placeholder="Contact Number" name="number" onChange={this.validator} />
                                <div className="text text-danger">{this.state.formErrors.number}</div>
                            </div>
                            <div className="form-group">
                                <label htmlFor="id" className="text-success font-weight-bold">Id<sup className="text-danger">*</sup>:</label>
                                <input type="text" value={this.state.formValues.email} className="form-control" id="fid" placeholder="Email" name="email" onChange={this.validator} />
                                <div className="text text-danger">{this.state.formErrors.email}</div>
                            </div>
                            <div className="form-group">
                                <label htmlFor="address" className="text-success font-weight-bold">Address<sup className="text-danger">*</sup>:</label>
                                <input type="text" value={this.state.formValues.address} className="form-control" id="address" placeholder="Address" name="address" onChange={this.validator} />
                                <div className="text text-danger">{this.state.formErrors.address}</div>
                            </div>

                            <button type="button" className="btn" disabled={!this.state.buttonActive} onClick={this.onSubmit} style={{width:"100%", backgroundColor:"#008000"}}>Submit</button>
                        </form>
                        </div>
                    </div>
                    <div className="col-md-3"></div>
                </div>
                <div className="container">
                    {this.state.fetchedData.length !== 0 ?
                        <table className="table table-striped table-bordered" style={{ tableLayout: "fixed" }}>
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Picture</th>
                                    <th>Number</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                {rowArr}
                            </tbody>
                        </table> : <br/>
                    }
                </div>
            </div>
        )
    }
}

export default Book;